
//////// AUTO OPEN/CLOSE NAVBAR ////////

// edituvav gotova skripta od net:

/* When the user scrolls down, hide the navbar. When the user scrolls up, show the navbar */
var prevScrollpos = window.pageYOffset;
window.onscroll = function () {
  var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0px";
    
  } else {
    document.getElementById("navbar").style.top = "-100%";
  }
  prevScrollpos = currentScrollPos;
}

/* Toggle between showing and hiding the navigation menu links when the user clicks on the hamburger menu / bar icon */
function myFunction() {
  var x = document.getElementById("myLinks");
  var b1 = document.getElementById("b1");
  var b2 = document.getElementById("b2");
  var b3 = document.getElementById("b3");

  if (x.style.height === "100vh") {

    // zatvori nav menu 
    x.style.height = "0px";
    
    // smeni go X-ot od hamburger menu 
    b2.style.borderColor = "var(--white)";
    b1.style.transform = "translateY(10px)";
    b3.style.transform = "translateY(-10px)";

  } else {
    // otvori nav menu 
    x.style.height = "100vh";

    //X od burger menu
    b2.style.borderColor = "transparent";
    b1.style.transform = "rotate(-45deg)";
    b3.style.transform = "rotate(45deg)";
  }
}



//////// DIV FOLLOW MOUSE //////////////////
// koristi external linknati skripti vo head 

var $circle = $('.follow');

function moveCircle(e) {
  TweenLite.to($circle, 0.3, {
    css: {
      left: e.pageX + 30,
      top: e.pageY + 30
    }
  });
}

$(window).on('mousemove', moveCircle);


///////////////////////////////////////////////
///// HERO BANNER BG RANDOM TRANSFORMS ///////
/////////////////////////////////////////////


var red = document.querySelector('#dl');
var blue = document.querySelector('#dd');


/////////////////////// TRANSLATE

function changer1() {

  var customx = Math.random() * -(150 - (-50)) - 50;
  var customy = Math.random() * -(150 - (-50)) - 50;

  //////

  red.style.setProperty('--custom-x', customx + 'px');
  red.style.setProperty('--custom-y', customy + 'px');
  //
  blue.style.setProperty('--custom-x', customx + 'px');
  blue.style.setProperty('--custom-y', customy + 'px');
}
setInterval(changer1, 1000);


////////////////////////// SCALE

function changer2() {

  var customsx = Math.random() * (200 - 50) + 50;
  var customsy = Math.random() * (200 - 50) + 50;
  ///////
  red.style.setProperty('--custom-sx', customsx + '%');
  red.style.setProperty('--custom-sy', customsy + '%');
  //
  blue.style.setProperty('--custom-sx', customsx + '%');
  blue.style.setProperty('--custom-sy', customsy + '%');
}
setInterval(changer2, 1250);

////////////////////////// ROTATE

function changer3() {

  var customr = Math.random() * (0 - 360);
  ////////
  red.style.setProperty('--custom-r', customr + 'deg');
  blue.style.setProperty('--custom-r', customr + 'deg');

}
setInterval(changer3, 1500);


// testimonials slider 

//ne raboti kako shto treba ama izgleda okej 🤫//

var moveL = 60;

function Larr() {

  var sliderL = document.querySelector("#testimonials-slider");

  sliderL.style.transform = "translateX( -" + moveL + "vw)";

  moveL = moveL + 60;

  if (moveL == 240) {
    moveL = 0;
  }
}

var moveR = -60;

function Rarr() {

  var sliderR = document.querySelector("#testimonials-slider");

  sliderR.style.transform = "translateX(" + moveR + "vw)";

  moveR = moveR - 60;

  if (moveR == -240) {
    moveR = 0;
  }
}


////////////////////////////////////////
// work section expand 
///////////////////////////////////////



//1
var rotate451 = 45;
var x1 = document.querySelector(".plus-1");
var i1 = document.querySelector(".w-img-1");
var c1 = document.querySelector(".w-txt-1");

//2
var rotate452 = 45;
var x2 = document.querySelector(".plus-2");
var i2 = document.querySelector(".w-img-2");
var c2 = document.querySelector(".w-txt-2");

//3
var rotate453 = 45;
var x3 = document.querySelector(".plus-3");
var i3 = document.querySelector(".w-img-3");
var c3 = document.querySelector(".w-txt-3");

//4
var rotate454 = 45;
var x4 = document.querySelector(".plus-4");
var i4 = document.querySelector(".w-img-4");
var c4 = document.querySelector(".w-txt-4");


//1
function wExpand1() {

  x1.style.transform = "rotate(" + rotate451 + "deg)";
  i1.style.height = "0px";
  c1.style.height = "0px";

  rotate451 = rotate451 + 45;
  if (rotate451 == 90) {
    rotate451 = 0;
    i1.style.height = "100%";
    c1.style.height = "100%";
  }
}

//2
function wExpand2() {

  x2.style.transform = "rotate(" + rotate452 + "deg)";
  i2.style.height = "0px";
  c2.style.height = "0px";

  rotate452 = rotate452 + 45;
  if (rotate452 == 90) {
    rotate452 = 0;
    i2.style.height = "100%";
    c2.style.height = "100%";
  }
}

//3
function wExpand3() {

  x3.style.transform = "rotate(" + rotate453 + "deg)";
  i3.style.height = "0px";
  c3.style.height = "0px";

  rotate453 = rotate453 + 45;
  if (rotate453 == 90) {
    rotate453 = 0;
    i3.style.height = "100%";
    c3.style.height = "100%";
  }
}

//4
function wExpand4() {

  x4.style.transform = "rotate(" + rotate454 + "deg)";
  i4.style.height = "0px";
  c4.style.height = "0px";

  rotate454 = rotate454 + 45;
  if (rotate454 == 90) {
    rotate454 = 0;
    i4.style.height = "100%";
    c4.style.height = "100%";
  }
}


